var DC726A_8ino =
[
    [ "loop", "DC726A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "manually_set_reg", "DC726A_8ino.html#aec619ebe2311e45a8f439ec25c79f9b9", null ],
    [ "print_prompt", "DC726A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC726A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "set_frequency", "DC726A_8ino.html#a18f76e87efc190f899316c3d4431fc6e", null ],
    [ "settings", "DC726A_8ino.html#a4b2eb9b1717bb7d76209b7c1de9aa0cb", null ],
    [ "setup", "DC726A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "output_config", "DC726A_8ino.html#a19274fea2fad587a5d4069ddaf8db9f2", null ]
];