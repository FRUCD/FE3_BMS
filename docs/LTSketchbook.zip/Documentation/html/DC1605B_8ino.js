var DC1605B_8ino =
[
    [ "loop", "DC1605B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "print_prompt", "DC1605B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1605B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_warning_prompt", "DC1605B_8ino.html#a7eba913bde59a1c1972f731a7586f393", null ],
    [ "setup", "DC1605B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC2936_I2C_ADDRESS", "DC1605B_8ino.html#a75d475164a40089ed87852bbc3fb9106", null ],
    [ "LTC2936_STATUS_WORD", "DC1605B_8ino.html#a704c463d9364856799393bc46251b70f", null ],
    [ "LTC2936_V2_THR", "DC1605B_8ino.html#a798757a7ab78615979485e9662754a56", null ],
    [ "ltc2936_i2c_address", "DC1605B_8ino.html#a451a571c0bba3adaa7229143aaa479a1", null ],
    [ "smbus", "DC1605B_8ino.html#a345ebedd28a646dfe8397c92eddc9b78", null ]
];