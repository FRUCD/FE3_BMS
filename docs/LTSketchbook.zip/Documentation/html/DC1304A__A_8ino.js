var DC1304A__A_8ino =
[
    [ "loop", "DC1304A__A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_filter_settings", "DC1304A__A_8ino.html#a24710a1e56bdd20abcb7ce6ec91770bb", null ],
    [ "menu_2_set_gpo", "DC1304A__A_8ino.html#a50e7e472ddc0f0aa393aa4d536ad985a", null ],
    [ "menu_3_shutdown", "DC1304A__A_8ino.html#a60ceb3cbaca25e526459bbd0637df6b7", null ],
    [ "print_prompt", "DC1304A__A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1304A__A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1304A__A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1304A__A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "filter_gain_settings", "DC1304A__A_8ino.html#ac6e82c70fb41cf941835163cebd7be8f", null ],
    [ "filter_hp_settings", "DC1304A__A_8ino.html#a8e8e68a0ec258f87a6b336bd9acf1a69", null ],
    [ "filter_lp_settings", "DC1304A__A_8ino.html#a189d792d42dd39fafb0ead4aebdf3251", null ],
    [ "gpio_settings", "DC1304A__A_8ino.html#ae72ab6fb159a2bc435f6ee4889048cf1", null ],
    [ "shdn_settings", "DC1304A__A_8ino.html#a2122b04973721c7d57fda5ee41547609", null ],
    [ "spi_out", "DC1304A__A_8ino.html#a52a1221e189b9a28b983318a19a7445e", null ]
];