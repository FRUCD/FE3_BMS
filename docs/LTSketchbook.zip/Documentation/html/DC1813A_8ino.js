var DC1813A_8ino =
[
    [ "loop", "DC1813A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_input", "DC1813A_8ino.html#a566d3e9aaa73069867f553dea44c455c", null ],
    [ "menu_2_select_bits", "DC1813A_8ino.html#a27d615db54600e86edf78045734fa110", null ],
    [ "print_prompt", "DC1813A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1813A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1813A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1813A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC2370_bits", "DC1813A_8ino.html#adfb922896513cb66eef594026da02772", null ],
    [ "LTC2370_vref", "DC1813A_8ino.html#af745f49c4c5530dd8505d7445706eaa8", null ]
];