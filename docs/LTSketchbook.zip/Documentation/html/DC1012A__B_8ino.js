var DC1012A__B_8ino =
[
    [ "loop", "DC1012A__B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_single_ended", "DC1012A__B_8ino.html#a26323c9b1c91dfe3fdbb4d00d8766fdf", null ],
    [ "menu_2_read_differential", "DC1012A__B_8ino.html#afae568c0df1a91394c078376683156b8", null ],
    [ "menu_3_set_address", "DC1012A__B_8ino.html#a338a4fe91dfdf0aef29ae96bd98c3c8d", null ],
    [ "print_prompt", "DC1012A__B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1012A__B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1012A__B_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1012A__B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "BUILD_COMMAND_DIFF", "DC1012A__B_8ino.html#aecd2bef5a7980968bf536307e3ecbb14", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "DC1012A__B_8ino.html#a089db05417baced654c68d2539ff1002", null ],
    [ "demo_board_connected", "DC1012A__B_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "i2c_address", "DC1012A__B_8ino.html#afd5dbf719bae2b1ea9260a55e7c289cf", null ],
    [ "LTC2497_vref", "DC1012A__B_8ino.html#abe2efa69d3bbd415872c36163eaad99c", null ],
    [ "timeout", "DC1012A__B_8ino.html#a7f1ad43d3bf79b40bc39dbb5a6c3a5ae", null ]
];