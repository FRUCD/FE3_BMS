var DC1563A_8ino =
[
    [ "loop", "DC1563A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_input", "DC1563A_8ino.html#a566d3e9aaa73069867f553dea44c455c", null ],
    [ "menu_2_select_bits", "DC1563A_8ino.html#a27d615db54600e86edf78045734fa110", null ],
    [ "menu_3_select_vref", "DC1563A_8ino.html#ab760f976d592692f9ead8c4430194acb", null ],
    [ "menu_4_select_part", "DC1563A_8ino.html#abf22b3e2dc2ea31f7a3baf32fcd8603e", null ],
    [ "print_prompt", "DC1563A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1563A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1563A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1563A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC2315_bits", "DC1563A_8ino.html#afc0e80f8e19c2514c409f9e111318b11", null ],
    [ "LTC2315_JP3", "DC1563A_8ino.html#a8abc5bfcf2fad80aa13f87cb6e7a2112", null ],
    [ "LTC2315_shift", "DC1563A_8ino.html#ab5ef02a68b6de53dd38f1bca6ab2d00e", null ],
    [ "LTC2315_vref", "DC1563A_8ino.html#a33bbfb78d0a59b0eaa0d9f38918ea6fa", null ]
];