var DC682A_8ino =
[
    [ "loop", "DC682A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_input", "DC682A_8ino.html#a566d3e9aaa73069867f553dea44c455c", null ],
    [ "menu_2_select_single_ended_differential", "DC682A_8ino.html#aa19e7903c686b5a4e0a7c581b5f6b056", null ],
    [ "menu_3_select_uni_bipolar", "DC682A_8ino.html#a409f2d13a4f4313c418f2a70fabe2e7b", null ],
    [ "menu_4_select_range", "DC682A_8ino.html#a5896bb5b0cc27ab079b4470c337c1e94", null ],
    [ "menu_5_sleep", "DC682A_8ino.html#a04aec2fe9c60183b298fffb8ee1970ca", null ],
    [ "print_channel_selection", "DC682A_8ino.html#a4767da61469af7d48c859f2593bdcd7f", null ],
    [ "print_prompt", "DC682A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC682A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command_differential", "DC682A_8ino.html#ac9eac7080495196595b686438f2bb254", null ],
    [ "print_user_command_single_ended", "DC682A_8ino.html#af8acb9b60fce76d543ed40826c8db9d6", null ],
    [ "setup", "DC682A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "BUILD_COMMAND_DIFF", "DC682A_8ino.html#acc623b3551359dcf8e66b344f86ad61e", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "DC682A_8ino.html#ac3dac851080025c8dfd854b08c7242f2", null ],
    [ "LTC1859_bits", "DC682A_8ino.html#a61e474990eba3b28e4816e9f4a76f19b", null ],
    [ "LTC1859_vref", "DC682A_8ino.html#ac72bb44f9a7f6d38372f2e94539f190a", null ],
    [ "range_low_high", "DC682A_8ino.html#a61b1e1cd8ff0b04e8897554d660ad133", null ],
    [ "single_ended_differential", "DC682A_8ino.html#ae3c7526de12753393417312b2a50a04e", null ],
    [ "uni_bipolar", "DC682A_8ino.html#a2a66cadfe70f01c77dc2ea6e51b2eaa6", null ]
];