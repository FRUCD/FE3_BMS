var DC1925A_8ino =
[
    [ "loop", "DC1925A_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_input", "DC1925A_8ino.html#a566d3e9aaa73069867f553dea44c455c", null ],
    [ "menu_2_select_gain_compression", "DC1925A_8ino.html#a4cb9e09bbff69848a8ed156c47dcedd7", null ],
    [ "print_prompt", "DC1925A_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1925A_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1925A_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1925A_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC2378_bits", "DC1925A_8ino.html#aebabbea724f0a054ce10fd95afde4e98", null ],
    [ "LTC2378_dgc", "DC1925A_8ino.html#a5b191f34e20261ebea209164ff5ffdab", null ],
    [ "LTC2378_vref", "DC1925A_8ino.html#aed13728f682fa85a1c65075d0c602d84", null ]
];