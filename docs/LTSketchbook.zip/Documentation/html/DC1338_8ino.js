var DC1338_8ino =
[
    [ "loop", "DC1338_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_single_ended_voltage", "DC1338_8ino.html#a31155a6de38efde836d1d0264e250934", null ],
    [ "menu_2_read_differential_voltage", "DC1338_8ino.html#a0472515fc4718d1aec5cb4d558159151", null ],
    [ "menu_3_read_temperature", "DC1338_8ino.html#a9b66de1f4cd44e0b793a4f5870708dd5", null ],
    [ "menu_4_settings", "DC1338_8ino.html#a07f3dadf795013af400915476a63f529", null ],
    [ "print_prompt", "DC1338_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1338_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "setup", "DC1338_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "demo_board_connected", "DC1338_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "LTC2990_DIFFERENTIAL_lsb", "DC1338_8ino.html#a4e2dddd9659fe0bbace6f7517236d0f8", null ],
    [ "LTC2990_DIODE_VOLTAGE_lsb", "DC1338_8ino.html#adf0b24560669e4c5d78c7b635d859eb7", null ],
    [ "LTC2990_SINGLE_ENDED_lsb", "DC1338_8ino.html#a82ac9f35c62a2c56269f46bdceae7a8c", null ],
    [ "LTC2990_TEMPERATURE_lsb", "DC1338_8ino.html#a9c6461ebe150227339c969276d4b7955", null ],
    [ "LTC2990_TIMEOUT", "DC1338_8ino.html#a3e2dd7c4cf40bc5c137af9e018da90d8", null ],
    [ "LTC2990_VCC_lsb", "DC1338_8ino.html#aa46e254be5b014b68dd1eedc3c923850", null ]
];