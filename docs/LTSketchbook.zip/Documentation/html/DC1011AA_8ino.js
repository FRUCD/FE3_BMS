var DC1011AA_8ino =
[
    [ "loop", "DC1011AA_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_single_ended", "DC1011AA_8ino.html#a5095ec15d6797f7bf28227f165dea415", null ],
    [ "menu_2_read_differential", "DC1011AA_8ino.html#a4a5d0562e0e2306d5e55741c8c694840", null ],
    [ "menu_3_read_temperature", "DC1011AA_8ino.html#aff0fba66cb060aa28da912f6464a4090", null ],
    [ "menu_4_set_1X2X", "DC1011AA_8ino.html#abecba87d56c933ab07d06094c731ec42", null ],
    [ "print_prompt", "DC1011AA_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1011AA_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1011AA_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1011AA_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "BUILD_1X_2X_COMMAND", "DC1011AA_8ino.html#af746eaf3f5a3843975e41ed0fe18708b", null ],
    [ "BUILD_COMMAND_DIFF", "DC1011AA_8ino.html#aecd2bef5a7980968bf536307e3ecbb14", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "DC1011AA_8ino.html#a089db05417baced654c68d2539ff1002", null ],
    [ "demo_board_connected", "DC1011AA_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "eoc_timeout", "DC1011AA_8ino.html#ac9e6544152d48e7780b787e2fb92c059", null ],
    [ "LTC2498_vref", "DC1011AA_8ino.html#a609f1d8238677c716508a476aa704583", null ],
    [ "rejection_mode", "DC1011AA_8ino.html#ac34538bf688df0a154db50a4af83111a", null ],
    [ "two_x_mode", "DC1011AA_8ino.html#a2b06467b3b344961c7a0141400d0591a", null ]
];