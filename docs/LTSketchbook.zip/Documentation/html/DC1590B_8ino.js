var DC1590B_8ino =
[
    [ "loop", "DC1590B_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "margin_high", "DC1590B_8ino.html#ad24eba757f22b0cb3c5eb940c36179b9", null ],
    [ "margin_low", "DC1590B_8ino.html#af827606f3b264da3c2ccd6a2c998c5f5", null ],
    [ "margin_off", "DC1590B_8ino.html#a406969080003754c99af9115a89047b8", null ],
    [ "menu_1_basic_commands", "DC1590B_8ino.html#a7527a48b62802b1a437d486387185207", null ],
    [ "print_all_currents", "DC1590B_8ino.html#a83f60db2107e897ca7e0310d18ecfb14", null ],
    [ "print_all_status", "DC1590B_8ino.html#a6e746fc6395b4ae1c2c2992b05b5e6dd", null ],
    [ "print_all_voltages", "DC1590B_8ino.html#aba50e71a3c450cbd99223847a65ccd3d", null ],
    [ "print_prompt", "DC1590B_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1590B_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_warning_prompt", "DC1590B_8ino.html#a7eba913bde59a1c1972f731a7586f393", null ],
    [ "sequence_off_on", "DC1590B_8ino.html#a9cd5e02c26e30ecb24bc0985a95d011c", null ],
    [ "setup", "DC1590B_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "LTC3880_I2C_ADDRESS", "DC1590B_8ino.html#ab70b4825068caf74e732c41836220547", null ],
    [ "ltc3880_i2c_address", "DC1590B_8ino.html#a1cd43b2d2a6e97e226b11a35afe1f7c5", null ],
    [ "pmbus", "DC1590B_8ino.html#a56d8d6b829d638afabaa5e61cce0801d", null ],
    [ "smbus", "DC1590B_8ino.html#a345ebedd28a646dfe8397c92eddc9b78", null ]
];