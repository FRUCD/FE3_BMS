var DC1012AA_8ino =
[
    [ "loop", "DC1012AA_8ino.html#a39a24a80bc3128a314bb15c85fc22cef", null ],
    [ "menu_1_read_single_ended", "DC1012AA_8ino.html#a26323c9b1c91dfe3fdbb4d00d8766fdf", null ],
    [ "menu_2_read_differential", "DC1012AA_8ino.html#afae568c0df1a91394c078376683156b8", null ],
    [ "menu_3_read_temperature", "DC1012AA_8ino.html#a9b66de1f4cd44e0b793a4f5870708dd5", null ],
    [ "menu_4_set_1X2X", "DC1012AA_8ino.html#abecba87d56c933ab07d06094c731ec42", null ],
    [ "menu_5_set_address", "DC1012AA_8ino.html#a4a7564f2641a28ae64438f3331b4dda7", null ],
    [ "print_prompt", "DC1012AA_8ino.html#a2ea477f9f0e79d6865887e79570ac386", null ],
    [ "print_title", "DC1012AA_8ino.html#a0b879bb0b1ef45ad46fc8331c59225f9", null ],
    [ "print_user_command", "DC1012AA_8ino.html#af1418f97589cbd2395d1d1769d29298b", null ],
    [ "setup", "DC1012AA_8ino.html#a90de5b68ab8defa635679fc0620fb698", null ],
    [ "BUILD_1X_2X_COMMAND", "DC1012AA_8ino.html#a3374294ba08fc021c168de751b1d3982", null ],
    [ "BUILD_COMMAND_DIFF", "DC1012AA_8ino.html#acf464fdcf6e3407e41d917cda1980a6d", null ],
    [ "BUILD_COMMAND_SINGLE_ENDED", "DC1012AA_8ino.html#a8e69cf8336d04905b5ca9690ef9f5aad", null ],
    [ "demo_board_connected", "DC1012AA_8ino.html#a1371f3fcb5f0942f131a857d01f04f93", null ],
    [ "eoc_timeout", "DC1012AA_8ino.html#ac9e6544152d48e7780b787e2fb92c059", null ],
    [ "i2c_address", "DC1012AA_8ino.html#afd5dbf719bae2b1ea9260a55e7c289cf", null ],
    [ "LTC2499_vref", "DC1012AA_8ino.html#a292cde7e5fe542d6b7c173682656eab2", null ],
    [ "rejection_mode", "DC1012AA_8ino.html#ac34538bf688df0a154db50a4af83111a", null ],
    [ "two_x_mode", "DC1012AA_8ino.html#a7f55451365eec7fe24c4c9024cbbbcbe", null ]
];